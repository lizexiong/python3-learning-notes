from django.apps import AppConfig


class AnalyseConfig(AppConfig):
    name = 'analyse'
