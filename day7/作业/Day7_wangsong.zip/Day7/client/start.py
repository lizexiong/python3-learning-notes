#!/usr/bin/env python
from conf import settings
from bin import ftpclient

if __name__ == "__main__":
    ftpclient.start()